//
//  Moto.cpp
//  dynamicCast
//
//  Created by Ichko  on 16/05/17.
//  Copyright © 2017 IliyaStark. All rights reserved.
//

#include "Moto.hpp"

#include <iostream>

using namespace std;

Moto::Moto(string make, string model, string chain):Auto(make,model)
{
    setChain(chain);
}

//

void Moto::setChain(string chain)
{
    this->chain = chain;
}

//

string Moto::getChain()
{
    return this->chain;
}

//

void Moto::showInfo()
{
    Auto::showInfo();
    
    cout << "Chain -> " << getChain() << endl;
}
