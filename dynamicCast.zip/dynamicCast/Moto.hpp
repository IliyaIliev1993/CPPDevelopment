//
//  Moto.hpp
//  dynamicCast
//
//  Created by Ichko  on 16/05/17.
//  Copyright © 2017 IliyaStark. All rights reserved.
//

#ifndef Moto_hpp
#define Moto_hpp

#include <iostream>

#include "Auto.hpp"

using namespace std;

class Moto : public Auto
{
private:
    
    string chain;
    
public:
    
    Moto(string,string,string);
    
    //
    
    void setChain(string);
    
    //
    
    string getChain();
    
    virtual void showInfo();
};

#endif /* Moto_hpp */
