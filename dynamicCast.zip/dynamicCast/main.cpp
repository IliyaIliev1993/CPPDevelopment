//
//  main.cpp
//  dynamicCast
//
//  Created by Ichko  on 16/05/17.
//  Copyright © 2017 IliyaStark. All rights reserved.
//

#include <iostream>

#include <vector>

#include "Auto.hpp"

#include "Moto.hpp"

using namespace std;

using std::vector;

int main(int argc, const char * argv[]) {
    
    Auto auto1("BMW", "320");
    
    Moto moto1("Kawasaki","Ninja","Chain");
    
    Auto *ptr = new Auto("Ford","Ka");
    
    Auto *autoPtr = &auto1;
    
    Moto *motoPtr = &moto1;
    
    vector<Auto*>myVector;
    
    myVector.push_back(autoPtr);
    
    myVector.push_back(motoPtr);
    
    myVector.push_back(ptr);
    
    for(int i = 0; i < myVector.size(); i++)
    {
        myVector[i]->showInfo();
        
        if(motoPtr == dynamic_cast<Moto*>(myVector[i]))
        {
            motoPtr->getChain();
        }
        if(ptr == dynamic_cast<Auto*>(myVector[i]))
           {
               ptr->showInfo();
           }
    }
    
    return 0;
}
