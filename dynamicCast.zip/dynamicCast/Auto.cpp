//
//  Auto.cpp
//  dynamicCast
//
//  Created by Ichko  on 16/05/17.
//  Copyright © 2017 IliyaStark. All rights reserved.
//

#include "Auto.hpp"

#include <iostream>

using namespace std;

Auto::Auto(string make, string model)
{
    setMake(make);
    
    setModel(model);
}


//

void Auto::setMake(string make)
{
    this->make = make;
}

void Auto::setModel(string model)
{
    this->model = model;
}

//

string Auto::getMake()
{
    return this->make;
}

string Auto::getModel()
{
    return this->model;
}

//

void Auto::showInfo()
{
    cout << "Make -> " << getMake() << endl;
    
    cout << "Model -> " << getModel() << endl;
}
