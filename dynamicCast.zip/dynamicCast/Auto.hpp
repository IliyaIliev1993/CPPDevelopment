//
//  Auto.hpp
//  dynamicCast
//
//  Created by Ichko  on 16/05/17.
//  Copyright © 2017 IliyaStark. All rights reserved.
//

#ifndef Auto_hpp
#define Auto_hpp

#include <iostream>

using namespace std;

class Auto
{
private:
    
    string make;
    
    string model;
    
public:
    
    Auto(string,string);
    
    void setMake(string);
    
    void setModel(string);
    
    //
    
    string getMake();
    
    string getModel();
    
    virtual void showInfo();
};

#endif /* Auto_hpp */
