//
//  main.cpp
//  WorkingWithFiles
//
//  Created by Ichko  on 12/05/17.
//  Copyright © 2017 IliyaStark. All rights reserved.
//

#include <iostream>

#include <fstream>

#include <cstdlib>

using std::exit;

using namespace std;

using std::ofstream;

int main(int argc, const char * argv[]) {
 
    ofstream myFile("info.txt",ios::out);
    
    if(myFile)
    {
        cout << "File loaded success !" << endl;
    }
    else
    {
        cout << "Could not open file !" << endl;
        
        exit(1);
    }
    
    cout << "Please enter FIRSTNAME, LASTNAME, EGN: " << endl;
    
    string firstName;
    
    string lastName;
    
    int egn;
    
    while(cin >> firstName >> lastName >> egn)
    {
        myFile << firstName << " " << lastName << " " << egn;
        
        cout << "Next Info -> " << endl;
    }
    
    
    return 0;
}
