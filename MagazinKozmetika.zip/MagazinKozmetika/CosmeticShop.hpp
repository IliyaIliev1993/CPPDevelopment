

#ifndef CosmeticShop_hpp
#define CosmeticShop_hpp

#include <iostream>

#include <vector>

#include "Manifactor.hpp"

using namespace std;

using std::vector;

class CosmeticShop
{
    
private:
    
    string nameArticul;
    
    string type;
    
    double price;
    
    double quantity;
    
    Manifactor manObj;
    
public:
    
    vector<CosmeticShop>myVector;
    
    CosmeticShop(string,string,double,double,Manifactor&);
    
    CosmeticShop();
    
    //
    
    void setNameArticul(string);
    
    void setType(string);
    
    void setPrice(double);
    
    void setQuantity(double);
    
    void setObject(Manifactor&);
    
    //
    
    string getNameArticul();
    
    string getType();
    
    double getPrice();
    
    double getQuantity();
    
    Manifactor& getObject();
    
    //
    
    void print();
    
    // vector functionality
    
    void add(CosmeticShop&);
    
    void filterByPrice(double);
    
    void filterByType();
    
    
    
    
};

#endif /* CosmeticShop_hpp */
