

#include "CosmeticShop.hpp"

#include <iostream>

using namespace std;

CosmeticShop::CosmeticShop(string nameArticul, string type, double price, double quantity, Manifactor& manObj):manObj(manObj)
{
    setNameArticul(nameArticul);
    
    setType(type);
    
    setPrice(price);
    
    setQuantity(quantity);
}

CosmeticShop::CosmeticShop():manObj()
{
    this->nameArticul = "";
    
    this->type = "";
    
    this->price = 0.0;
    
    this->quantity = 0.0;
}

//

void CosmeticShop::setNameArticul(string nameArticul)
{
    this->nameArticul = nameArticul;
}

void CosmeticShop::setType(string type)
{
    this->type = type;
}

void CosmeticShop::setPrice(double price)
{
    this->price = price;
}

void CosmeticShop::setQuantity(double quantity)
{
    this->quantity = quantity;
}

void CosmeticShop::setObject(Manifactor& object)
{
    this->manObj = object;
}

//

string CosmeticShop::getNameArticul()
{
    return this->nameArticul;
}

string CosmeticShop::getType()
{
    return this->type;
}

double CosmeticShop::getPrice()
{
    return this->price;
}

double CosmeticShop::getQuantity()
{
    return this->quantity;
}

Manifactor& CosmeticShop::getObject()
{
    return this->manObj;
}

//

void CosmeticShop::print()
{
    cout << "Name Articul: " << getNameArticul() << endl;
    
    cout << "Type: " << getType() << endl;
    
    cout << "Price: " << getPrice() << endl;
    
    cout << "Quantity: " << getQuantity() << endl;
    
    manObj.print();

}

// vector functionality

void CosmeticShop::add(CosmeticShop& obj)
{
    for(int i = 0; i < myVector.size(); i++)
    {
        if(myVector[i].getNameArticul() == obj.getNameArticul() && myVector[i].getObject().getName() == obj.getObject().getName())
        {
            cout << "exist" << endl;
            
            return;
        }
    }
    
    myVector.push_back(obj);
    
}

void CosmeticShop::filterByPrice(double priceFilter)
{
    for(int i = 0; i < myVector.size(); i++)
    {
        if(priceFilter >= myVector[i].getPrice())
        {
            myVector[i].print();
        }
    }
}

void CosmeticShop::filterByType()
{
    int crem = 0;
    
    int pudra = 0;
    
    int spray = 0;
    
    for(int i = 0; i < myVector.size(); i++)
    {
        if(myVector[i].getType() == "Crema")
        {
            crem = crem + 1;
        }
        if(myVector[i].getType() == "Pudra")
        {
            pudra = pudra + 1;
        }
        if(myVector[i].getType() == "Spray")
        {
            spray = spray + 1;
        }
    }
    
    cout << "Crema: " << crem << endl;
    
    cout << "Pudra: " << pudra << endl;
    
    cout << "Spray: " << spray << endl;
}
