
#include "Manifactor.hpp"

#include <iostream>

using namespace std;

Manifactor::Manifactor(string name, int code, string country)
{
    setName(name);
    
    setCode(code);
    
    setCountry(country);
}

Manifactor::Manifactor()
{
    this->name = "";
    
    this->code = 0;
    
    this->country = "";
}

//

void Manifactor::setName(string name)
{
    this->name = name;
}

void Manifactor::setCode(int code)
{
    this->code = code;
}

void Manifactor::setCountry(string country)
{
    this->country = country;
}

//

string Manifactor::getName()
{
    return this->name;
}

int Manifactor::getCode()
{
   return this->code;
}

string Manifactor::getCountry()
{
    return this->country;
}

//

void Manifactor::print()
{
    cout << "Name: " << getName() << endl;
    
    cout << "Code: " << getCode() << endl;
    
    cout << "Country: " << getCountry() << endl;
}
