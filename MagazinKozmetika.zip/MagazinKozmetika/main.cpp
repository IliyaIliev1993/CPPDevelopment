

#include <iostream>

#include "Manifactor.hpp"

#include "CosmeticShop.hpp"

using namespace std;

int main(int argc, const char * argv[]) {
    
    
    Manifactor man1("Aroma",1234,"BG");
    
    CosmeticShop cos1("Fon","Pudra",15.50,1,man1);
    
    CosmeticShop cosAdd;
    
    cosAdd.add(cos1);
    
    cosAdd.filterByType();
    
    cosAdd.filterByPrice(15.50);
    
    cosAdd.add(cos1);
    
    cosAdd.filterByPrice(15.50);
    
    
    return 0;
}
