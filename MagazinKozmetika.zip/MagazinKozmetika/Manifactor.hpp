

#ifndef Manifactor_hpp
#define Manifactor_hpp

#include <iostream>

using namespace std;

class Manifactor
{
private:
    
    string name;
    
    int code;
    
    string country;
    
public:
    
    Manifactor(string,int,string);
    
    Manifactor();
    
    void setName(string);
    
    void setCode(int);
    
    void setCountry(string);
    
    string getName();
    
    int getCode();
    
    string getCountry();
    
    void print();
};

#endif /* Manifactor_hpp */
