//
//  main.cpp
//  ReadingFiles
//
//  Created by Ichko  on 12/05/17.
//  Copyright © 2017 IliyaStark. All rights reserved.
//

#include <iostream>

#include <fstream>

#include <vector>

using std::vector;

using namespace std;

using std::ifstream;

int main(int argc, const char * argv[]) {
    vector<int>myVector;
    
    string make;
    
    string model;
    
    int year;
    
    string fuel;
    
    int sum = 0;
    
    ifstream reading("File.txt",ios::in);
    
    if(reading)
    {
        cout << "File -> " << "File.txt " << "succesfully loaded !" << endl;
    }
    else
    {
        cout << "File couldn't be open..." << endl;
        
        exit(0);
    }
    
    cout << endl;
  
    cout << "Car - " << "Model - " << "Year - " << "Fuel" << endl;
    
    while(reading >> make >> model >> year >> fuel)
    {
        cout << make << " - " << model << " - " << year << " - " << fuel << endl;
        
        sum = sum + year;
        
        myVector.push_back(year);
    
    }
    
    cout << endl;
    
    cout << "The sum is of the years is -> " << sum << endl;
    
    cout << endl;
    
    for(int i = 0; i < myVector.size(); i++)
    {
        cout << myVector[i] << endl;
    }
    
    
    return 0;
}
